package com.Eric.APIv2.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "tokens_firebase")
public class TokenFirebase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String email;

    @Column(columnDefinition = "TEXT")
    private String token;

    @Column(nullable = false)
    private LocalDateTime dataCadastro = LocalDateTime.now();

    public TokenFirebase() {}

    public TokenFirebase(String email, String token) {
        this.email = email;
        this.token = token;
    }

    // Getters e Setters
    public Long getId() { return id; }
    public String getEmail() { return email; }
    public String getToken() { return token; }
    public LocalDateTime getDataCadastro() { return dataCadastro; }

    public void setEmail(String email) { this.email = email; }
    public void setToken(String token) { this.token = token; }
}
