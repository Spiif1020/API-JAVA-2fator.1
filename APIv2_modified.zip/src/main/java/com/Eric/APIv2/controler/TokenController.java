package com.Eric.APIv2.controler;

import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import com.Eric.APIv2.model.TokenFirebase;
import com.Eric.APIv2.repository.TokenRepository;

import java.util.List;

@RestController
@RequestMapping("/api/tokens")
@CrossOrigin("*") // libera acesso para o app Android
public class TokenController {

    @Autowired
    private TokenRepository tokenRepository;

    // ✅ POST - recebe e salva token
    @PostMapping
    public TokenFirebase salvarToken(@RequestBody TokenFirebase token) {
        System.out.println("📩 Token recebido: " + token.getToken());
        return tokenRepository.save(token);
    }

    // ✅ GET - lista tokens salvos
    @GetMapping
    public List<TokenFirebase> listarTokens() {
        return tokenRepository.findAll();
    }
}
