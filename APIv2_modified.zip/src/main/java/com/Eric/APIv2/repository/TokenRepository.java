package com.Eric.APIv2.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.Eric.APIv2.model.TokenFirebase;

public interface TokenRepository extends JpaRepository<TokenFirebase, Long> {}