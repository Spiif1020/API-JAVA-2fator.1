package com.Eric.APIv2.payment;

import org.springframework.stereotype.Service;
import com.google.firebase.messaging.*;
import java.util.HashMap;
import java.util.Map;

@Service
public class FcmService {

    public void sendPurchaseNotification(Transaction tx, String deviceToken) {
        Map<String, String> data = new HashMap<>();
        data.put("transactionId", String.valueOf(tx.getId()));
        data.put("amount", String.valueOf(tx.getAmount()));
        data.put("type", "purchase_request");

        Notification notification = Notification.builder()
            .setTitle("Compra pendente")
            .setBody("Compra de R$ " + tx.getAmount() + " aguardando sua aprovação.")
            .build();

        Message message = Message.builder()
            .putAllData(data)
            .setNotification(notification)
            .setToken(deviceToken)
            .build();

        try {
            String resp = FirebaseMessaging.getInstance().send(message);
            System.out.println("FCM sent: " + resp);
        } catch (FirebaseMessagingException e) {
            e.printStackTrace();
        }
    }

    public void sendDecisionNotification(Transaction tx, String deviceToken) {
        Map<String, String> data = new HashMap<>();
        data.put("transactionId", String.valueOf(tx.getId()));
        data.put("status", tx.getStatus());
        data.put("type", "purchase_decision");

        Notification notification = Notification.builder()
            .setTitle("Transação " + tx.getStatus())
            .setBody("Sua transação de R$ " + tx.getAmount() + " foi " + tx.getStatus())
            .build();

        Message message = Message.builder()
            .putAllData(data)
            .setNotification(notification)
            .setToken(deviceToken)
            .build();

        try {
            String resp = FirebaseMessaging.getInstance().send(message);
            System.out.println("FCM decision sent: " + resp);
        } catch (FirebaseMessagingException e) {
            e.printStackTrace();
        }
    }
}
