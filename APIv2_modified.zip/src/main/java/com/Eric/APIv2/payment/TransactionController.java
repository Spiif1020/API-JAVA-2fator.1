package com.Eric.APIv2.payment;

import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import com.Eric.APIv2.repository.TokenRepository;
import com.Eric.APIv2.model.TokenFirebase;
import java.util.Optional;

@RestController
@RequestMapping("/api")
@CrossOrigin("*")
public class TransactionController {

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private FcmService fcmService;

    @Autowired
    private TokenRepository tokenRepository;

    @PostMapping("/purchase")
    public Transaction purchase(@RequestBody PurchaseRequest request) {
        Transaction tx = new Transaction(request.getCardNumber(), request.getAmount(), request.getEmail());
        transactionRepository.save(tx);

        // Busca token do usuário por email (assumindo que o app registrou o email)
        Optional<TokenFirebase> opt = tokenRepository.findAll().stream()
                .filter(t -> t.getEmail() != null && t.getEmail().equalsIgnoreCase(request.getEmail()))
                .findFirst();

        if (opt.isPresent()) {
            fcmService.sendPurchaseNotification(tx, opt.get().getToken());
        } else {
            // caso não tenha token, apenas loga
            System.out.println("Nenhum token FCM encontrado para o email: " + request.getEmail());
        }

        return tx;
    }

    @PostMapping("/transactions/{id}/decision")
    public Transaction decide(@PathVariable Long id, @RequestParam("approved") boolean approved) {
        Transaction tx = transactionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Transação não encontrada"));

        tx.setStatus(approved ? "APPROVED" : "REJECTED");
        transactionRepository.save(tx);

        // opcional: enviar notificação de confirmação de status
        // buscar token e enviar notificação simples
        tokenRepository.findAll().stream()
            .filter(t -> t.getEmail()!=null && t.getEmail().equalsIgnoreCase(tx.getEmail()))
            .findFirst()
            .ifPresent(t -> fcmService.sendDecisionNotification(tx, t.getToken()));

        return tx;
    }
}
