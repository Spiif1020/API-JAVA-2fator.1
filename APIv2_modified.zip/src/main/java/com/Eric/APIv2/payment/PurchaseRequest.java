package com.Eric.APIv2.payment;

public class PurchaseRequest {
    private String cardNumber;
    private Double amount;
    private String email;

    public PurchaseRequest() {}
    public String getCardNumber() { return cardNumber; }
    public Double getAmount() { return amount; }
    public String getEmail() { return email; }
    public void setCardNumber(String cardNumber) { this.cardNumber = cardNumber; }
    public void setAmount(Double amount) { this.amount = amount; }
    public void setEmail(String email) { this.email = email; }
}
