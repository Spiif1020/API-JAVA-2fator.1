package com.Eric.APIv2.payment;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "transactions")
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String cardNumber;
    private Double amount;
    private String status; // PENDING, APPROVED, REJECTED
    private String email; // dono do cartão / usuário
    private LocalDateTime createdAt;

    public Transaction() {}

    public Transaction(String cardNumber, Double amount, String email) {
        this.cardNumber = cardNumber;
        this.amount = amount;
        this.email = email;
        this.status = "PENDING";
        this.createdAt = LocalDateTime.now();
    }

    // getters e setters
    public Long getId() { return id; }
    public String getCardNumber() { return cardNumber; }
    public Double getAmount() { return amount; }
    public String getStatus() { return status; }
    public String getEmail() { return email; }
    public LocalDateTime getCreatedAt() { return createdAt; }

    public void setId(Long id) { this.id = id; }
    public void setCardNumber(String cardNumber) { this.cardNumber = cardNumber; }
    public void setAmount(Double amount) { this.amount = amount; }
    public void setStatus(String status) { this.status = status; }
    public void setEmail(String email) { this.email = email; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
