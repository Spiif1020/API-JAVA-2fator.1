package com.Eric.APIv2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class ApIv2Application {

	public static void main(String[] args) {
		SpringApplication.run(ApIv2Application.class, args);
	}

}
