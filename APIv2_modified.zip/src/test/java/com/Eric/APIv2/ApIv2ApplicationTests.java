package com.Eric.APIv2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApIv2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
